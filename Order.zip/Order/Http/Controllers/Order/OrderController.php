<?php

namespace Modules\Order\Http\Controllers\Order;

use App\Http\Controllers\Controller;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Modules\Order\Entities\Order;

class OrderController extends Controller
{
    protected $model = Order::class;

    protected $viewPath = 'order::admin.orders';

    public function index()
    {
        return view("{$this->viewPath}.index");
    }

    public function show()
    {
        return view("{$this->viewPath}.show");
    }
}
//thêm "modules/Order/Resources/assets/admin/sass/print.scss", vào dòng 19 file vite.config.js
