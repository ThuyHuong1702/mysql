<div class="address-information-wrapper">
    <h4 class="section-title">{{ trans('order::orders.address_information') }}</h4>

    <div class="row">
        <div class="col-md-6">
            <div class="billing-address">
                <h5 class="pull-left">{{ trans('order::orders.billing_address') }}</h5>

                <span>
                    {{-- billing_full_name --}}
                    Demo Admin
                    <br>
                    {{-- billing_address_1 --}}
                    Savar
                    <br>

                    {{-- billing_address_2 --}}
                    Dhaka, Dhaka 1344
                    <br>

                    {{-- billing_city billing_state_name billing_zip --}}
                    BangOccaecat neque ex ex, North Carolina 74211

                    <br>
                    {{-- billing_country_name --}}
                    United Statesladesh
                </span>
            </div>
        </div>

        <div class="col-md-6">
            <div class="shipping-address">
                <h5 class="pull-left">{{ trans('order::orders.shipping_address') }}</h5>

                <span>
                    {{-- billing_full_name --}}
                    Demo Admin
                    <br>
                    {{-- billing_address_1 --}}
                    Savar
                    <br>

                    {{-- billing_address_2 --}}
                    Dhaka, Dhaka 1344
                    <br>

                    {{-- billing_city billing_state_name billing_zip --}}
                    BangOccaecat neque ex ex, North Carolina 74211

                    <br>
                    {{-- billing_country_name --}}
                    United Statesladesh
                </span>
            </div>
        </div>
    </div>
</div>
