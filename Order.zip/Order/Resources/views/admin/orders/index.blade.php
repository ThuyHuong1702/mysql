@extends('admin::layout')

@component('admin::components.page.header')
    @slot('title', trans('order::orders.orders'))

    <li class="active">{{ trans('order::orders.orders') }}</li>
@endcomponent

@section('content')
    <div class="box box-primary">
        <div class="box-body index-table" id="orders-table">
            @component('admin::components.table')
                @slot('thead')
                    <tr>
                        <th>{{ trans('admin::admin.table.id') }}</th>
                        <th style="width: 24%;">
                            <a href="{{ route('admin.orders.show', 1500) }}">
                                {{ trans('order::orders.table.customer_name') }}
                            </a>
                        </th>
                        <th style="width: 24%;">{{ trans('order::orders.table.customer_email') }}</th>
                        <th>{{ trans('admin::admin.table.status') }}</th>
                        <th>{{ trans('order::orders.table.total') }}</th>
                        <th data-sort>{{ trans('admin::admin.table.created') }}</th>
                    </tr>
                @endslot

                @slot('tbody')
                    <tr class="clickable-row">
                        <td class="dt-type-numeric">1500</td>
                        <td>
                            <a href="show.blade.php">Demo Admin</a>
                        </td>
                        <td>admin@email.com</td>
                        <td><span class="badge badge-info">Pending</span></td>
                        <td class="dt-type-numeric">750.000đ</td>
                        <td class="sorting_1">
                            <span data-toggle="tooltip" title="Apr 16, 2025">
                                10 hours ago
                            </span>
                        </td>
                    </tr>
                @endslot
            @endcomponent
        </div>
    </div>
@endsection

@push('scripts')
    <script type="module">

    </script>
@endpush
