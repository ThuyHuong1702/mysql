<?php

return [
    'invoice' => 'INVOICE',
    'invoice_id' => 'Invoice ID',
    'date' => 'Date',
    'order_details' => 'Order Details',
    'email' => 'Email',
    'phone' => 'Phone',
    'shipping_method' => 'Shipping Method',
    'payment_method' => 'Payment Method',
    'billing_address' => 'Billing Address',
    'shipping_address' => 'Shipping Address',
    'product' => 'Product',
    'unit_price' => 'Unit Price',
    'quantity' => 'Quantity',
    'line_total' => 'Line Total',
    'subtotal' => 'Subtotal',
    'total' => 'Total',
];
