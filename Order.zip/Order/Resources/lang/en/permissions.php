<?php

return [
    'index' => 'Index Order',
    'show' => 'Show Order',
    'edit' => 'Edit Order',
];
